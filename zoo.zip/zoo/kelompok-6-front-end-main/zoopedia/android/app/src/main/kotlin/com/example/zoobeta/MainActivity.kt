package com.example.zoobeta

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
